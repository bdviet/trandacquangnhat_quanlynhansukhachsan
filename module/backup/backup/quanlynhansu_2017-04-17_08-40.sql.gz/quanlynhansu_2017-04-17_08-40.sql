#SKD101|quanlynhansu|20|2017.04.17 08:40:29|111|11|1|7|1|10|13|3|12|8|3|2|7|2|4|5|3|6|9|4

DROP TABLE IF EXISTS `tlb_bangcap`;
CREATE TABLE `tlb_bangcap` (
  `bang_cap_id` varchar(10) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `ten_bang_cap` varchar(50) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  PRIMARY KEY (`bang_cap_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_bangcap` VALUES